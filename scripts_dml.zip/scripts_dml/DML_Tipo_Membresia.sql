-- Script DML para la tabla Tipo_Membresia
-- Fecha de generación: 2025-05-03 08:05:19.811397
-- Total de registros: 2

INSERT INTO dbo.Tipo_Membresia (IDTipoMembresia, Nombre) VALUES
  (1, 'Básica'),
  (2, 'Premium');

