-- Script DML para la tabla Pais
-- Fecha de generación: 2025-05-03 08:05:19.812324
-- Total de registros: 3

INSERT INTO dbo.Pais (IDPais, Nombre) VALUES
  (1, 'Guatemala'),
  (2, 'México'),
  (3, 'Estados Unidos');

