-- Script DML para la tabla Sucursal
-- Fecha de generación: 2025-05-03 08:05:19.812967
-- Total de registros: 8

INSERT INTO dbo.Sucursal (IDSucursal, Nombre, Capacidad, Direccion, IDCiudad) VALUES
  (1, 'FitChain Nueva York', 107, 'Urbanización de Jacinto Chaparro 9
Palencia, 28651', 6),
  (2, 'FitChain Ciudad de Guatemala', 429, 'Glorieta Joan Vazquez 408
Ceuta, 30439', 1),
  (3, 'FitChain Ciudad de México', 175, 'Ronda Noé Lobo 63
Ávila, 25898', 3),
  (4, 'FitChain Xela', 121, 'Callejón de Noemí Aroca 28 Piso 1 
Santa Cruz de Tenerife, 41535', 2),
  (5, 'FitChain Nueva York', 102, 'Calle Gisela Goñi 41
Jaén, 19217', 6),
  (6, 'FitChain Nueva York', 429, 'Acceso Pedro Gallego 31 Puerta 3 
Lleida, 25867', 6),
  (7, 'FitChain Miami', 94, 'Calle de Jenaro Antón 56
Castellón, 38170', 5),
  (8, 'FitChain Miami', 266, 'C. de Soledad Segarra 34
Valencia, 37789', 5);

