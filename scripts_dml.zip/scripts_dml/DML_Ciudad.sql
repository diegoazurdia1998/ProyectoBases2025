-- Script DML para la tabla Ciudad
-- Fecha de generación: 2025-05-03 08:05:19.812622
-- Total de registros: 6

INSERT INTO dbo.Ciudad (IDCiudad, Nombre, IDPais) VALUES
  (1, 'Ciudad de Guatemala', 1),
  (2, 'Xela', 1),
  (3, 'Ciudad de México', 2),
  (4, 'Guadalajara', 2),
  (5, 'Miami', 3),
  (6, 'Nueva York', 3);

