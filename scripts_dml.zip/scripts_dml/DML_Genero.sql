-- Script DML para la tabla Genero
-- Fecha de generación: 2025-05-03 08:05:19.810998
-- Total de registros: 3

INSERT INTO dbo.Genero (IDGenero, Nombre) VALUES
  (1, 'Masculino'),
  (2, 'Femenino'),
  (3, 'Otro');

