-- Script DML para la tabla Estado
-- Fecha de generación: 2025-05-03 08:05:19.811735
-- Total de registros: 4

INSERT INTO dbo.Estado (IDEstado, Nombre) VALUES
  (1, 'Activo'),
  (2, 'Completado'),
  (3, 'Fallido'),
  (4, 'En progreso');

