-- Script DML para la tabla Grupo
-- Fecha de generación: 2025-05-03 08:05:19.814102
-- Total de registros: 15

INSERT INTO dbo.Grupo (IDGrupo, Nombre, Fecha_creacion) VALUES
  (1, 'Grupo Minima', '2025-04-05 00:00:00'),
  (2, 'Grupo Vel', '2023-06-23 00:00:00'),
  (3, 'Grupo Totam', '2025-01-13 00:00:00'),
  (4, 'Grupo Doloremque', '2024-09-23 00:00:00'),
  (5, 'Grupo Asperiores', '2024-02-21 00:00:00'),
  (6, 'Grupo Nam', '2023-12-25 00:00:00'),
  (7, 'Grupo Sunt', '2025-01-14 00:00:00'),
  (8, 'Grupo Inventore', '2024-04-28 00:00:00'),
  (9, 'Grupo Voluptates', '2023-12-14 00:00:00'),
  (10, 'Grupo Eveniet', '2025-02-13 00:00:00'),
  (11, 'Grupo Nobis', '2023-11-14 00:00:00'),
  (12, 'Grupo Ullam', '2025-01-28 00:00:00'),
  (13, 'Grupo Consectetur', '2024-01-15 00:00:00'),
  (14, 'Grupo Voluptatibus', '2025-03-28 00:00:00'),
  (15, 'Grupo Consequatur', '2025-03-09 00:00:00');

